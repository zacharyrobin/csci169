//
//  Apple.h
//  hw5b

//  Copyright © 2019 Zach. All rights reserved.
//

#ifndef Apple_h
#define Apple_h
#include "fruit.h"
class Apple : public Fruit{
private:
    
public:
    //connstructors
    Apple() {
        Fruit();
    }
    Apple(Date r){
        
        Fruit(r, "apple");
    }
    void prepare(){
        
        std::cout<<"Core the" + this->getName();
    }
};
#endif /* Apple_h */
