//
//  fruit.h
//  hw5b

//  Copyright © 2019 Zach. All rights reserved.
//

#ifndef fruit_h
#define fruit_h
#include "Food.h"
#include "Date.h"
class Fruit : virtual Food{
private:

public:
    Date ripe;
    std::string name;
    Fruit() {
        // Food's default constructor
        Date ripe;
    }
    void ripeTime()
    {
        std::cout << "You can eat it on " + ripe.print();
    }
    
    Fruit(Date r, std::string n)
    {
        ripe = r;
        name = n;
    }
    
    //getter
    std::string getName(){
        return name;
    }
    
};

#endif /* fruit_h */
