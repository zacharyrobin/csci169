//
//  Food.h
//  hw5b

//  Copyright © 2019 Zach. All rights reserved.
//
#ifndef Food_h
#define Food_h

class Food
{
private:

public:
    std::string name;
    // constructors
    Food()
    {
        name = "";
    }
    Food(std::string s)
    {
        name = s;
    }
    void  prepare()
    {
        std::cout<<"Prepare the " + name;
    }
    
};
#endif /* Food_h */
