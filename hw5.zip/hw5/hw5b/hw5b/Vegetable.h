//
//  Vegetable.h
//  hw5b

//  Copyright © 2019 Zach. All rights reserved.
//

#ifndef Vegetable_h
#define Vegetable_h
#include "Food.h"
#include "Date.h"
class Vegetable : virtual Food{
private:

public:
    Date exTime;
    Vegetable()
    {
        name = "";
        exTime = null;
    }
    Vegetable(std::string s, Date d)
    {
        name = s;
        exTime = d;
    }
};

#endif /* Vegetable_h */
