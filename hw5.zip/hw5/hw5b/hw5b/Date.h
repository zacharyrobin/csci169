//
//  Date.h
//  hw5b

//  Copyright © 2019 Zach. All rights reserved.
//

#ifndef Date_h
#define Date_h
#include <string>
#include <iostream>

class Date
{
private:
    int month, day, year;
public:
    // constructor sets the date to now
    Date();
    // set date month day year
    Date(int, int, int);
    
    // compares dates
    bool compare(const Date& d);
    
    std::string print()
    {
        return std::to_string(year) + " " + std::to_string(month) + " " + std::to_string(day);
    }

};

Date::Date(int Month, int Day, int Year)
{
    month = Month;
    day = Day;
    year = Year;
}

// Returns 1 if a is greater than or equal to b
bool Date :: compare (const Date& d) {
    
    if (year<d.year) {
        return 0;
    }
    else if (year>d.year) {
        return 1;
    }
    else if (month<d.month) {
        return 0;
    }
    else if (month>d.month) {
        return 1;
    }
    else if (day<d.day) {
        return 0;
    }
    else if (day>d.day) {
        return 1;
    }
    return 0;
}

#endif /* Date_h */
