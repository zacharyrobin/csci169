//
//  Tomato.h
//  hw5b

//  Copyright © 2019 Zach. All rights reserved.
//

#ifndef Tomato_h
#define Tomato_h
#include "Vegetable.h"

class Tomato : public Vegetable, public Fruit {
private:
    
public:
    Tomato(Date ex, Date ri, std::string n)
    {
        ripe = ri;
        exTime = ex;
        name = n;
    }
    
};
#endif /* Tomato_h */
