//
//  Orange.h
//  hw5b

//  Copyright © 2019 Zach. All rights reserved.
//

#ifndef Orange_h
#define Orange_h
#include "fruit.h"

class Orange : public Fruit
{

public:
    //connstructors 
    Orange() {
        Fruit();
    }
    Orange(Date r){
        
        Fruit(r, "orange");
    }
    void prepare(){
        
        std::cout<<"Peel the " + name;
    }
};

#endif /* Orange_h */
