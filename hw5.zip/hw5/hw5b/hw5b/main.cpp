// Zachary Robin
// Dr. Linnell
// Programming HW 5b
//  main.cpp

//  Copyright © 2019 Zach. All rights reserved.
//

#include <iostream>
#include "fruit.h"
#include "Food.h"
#include "Date.h"
#include "Orange.h"
#include "Apple.h"
#include "Tomato.h"
#include "Vegetable.h"
#include <vector>

int main(int argc, const char * argv[]) {
    std::vector<std::string> al;
    al.push_back("Food");
    al.push_back("Orange");
    al.push_back("Fruit");
    al.push_back("Papaya");
    al.push_back(3932728);
    al.push_back("Apple");
    al.push_back("now");
    al.push_back("Food");
    al.push_back("sandwich");
    
    // vector of outitems
    std::vector <Food> out;
    
    for(int i=0;i<al.size();i++)
    {
        std::string o = al.at(i);
        if(o == "Food")
        {
            if((al.at(i+1) != "Orange") && (al.at(i+1) != "Apple") && (al.at(i+1) != "Fruit") && (typeid(al.at(i+1)) == std::string))
            {
                Food f = new Food(static_cast<std::string>(al.at(i+1)));
                out.push_back(f);
            }
            else
            {
                Food f = new Food(static_cast<std::string>(al.at(i)));
                out.push_back(f);
            }
            
        }
        else if(o == "Fruit")
        {
            if((al.at(i + 1) != "Orange") && (al.at(i + 1) != "Apple"))
            {
                if(typeid(al.at(i+2)) == int)
                {
                    Date d = new Date(static_cast<int>(al.at(i + 2));
                    Fruit fr = new Fruit(d, al.at(i+1).toString());
                    out.push_back(fr);
                }
                else
                {
                    Fruit fr = new Fruit(null, al.at(i+1).toString());
                    out.push_back(fr);
                }
            }
        }
        else if(o == "Apple")
        {
            if(typeid(al.at(i+1)) == int)
            {
                Date d = new Date((int) al.at(i + 2));
                Apple fr = new Apple(d);
                out.push_back(fr);
            }
            else
            {
                Apple ap = new Apple();
                out.push_back(ap);
            }
        }
        else if(o == "Orange")
        {
            
            if(typeid(al.at(i+1)) == int)
            {
                Date d = new Date((int) al.at(i + 2));
                Orange fr = new Orange(d);
                out.push_back(fr);
            }
            else
            {
                Orange or = new Orange();
                out.push_back(or);
            }
        }
        
    }
    
    for(int i=0; i <out.size(); i++)
    {
        std::cout<<typeid(out.at(i));
    }
    
    std::cout<< "sorted: ";
    
    Collections.sort(out);
    for(int i=0; i <out.size(); i++)
    {
        std::cout<<typeid(out.at(i));
    }
    return 0;
}
